/**
*********************************************************************************
* @file    main.h
* @author  Alex
* @version V1.0
* @date    
* @brief   
*********************************************************************************
*/

#ifndef ___H
#define ___H

#include "stm32f1xx_hal.h"
#include "stm32f103xb.h"
#include <stdint.h>

void Error_Handler(char* ErrorMessage);
void SystemClock_Config(void);

#endif /* ___H */
