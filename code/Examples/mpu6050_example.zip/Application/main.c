#include "main.h"
#include "mpu6050.h"
#include "OLED.h"

int main(void)
{
	MPU6050_Data_Struct MPU_Data;

	HAL_Init();

	OLED_Init();
	OLED_clear();

	MPU_Init();
	HAL_Delay(500);
	MPU_DMP_Init();
	HAL_Delay(500);

	OLED_showString(2, 1, "pitch:");
	OLED_showString(3, 1, "roll:");
	OLED_showString(4, 1, "yaw:");
	OLED_showString(1, 1, "Test2");

	while (1) {
		while (MPU_GetData(&MPU_Data)) {}
		MPU_Get_Accelerometer(&MPU_Data);
		MPU_Get_Gyroscope(&MPU_Data);
		HAL_Delay(1000);
		OLED_showNum(2, 8, (uint32_t)MPU_Data.pitch * 100, 3);
		OLED_showNum(3, 8, (uint32_t)MPU_Data.roll * 100, 3);
		OLED_showNum(4, 8, (uint32_t)MPU_Data.yaw * 100, 3);
		HAL_Delay(500);
	}
}
